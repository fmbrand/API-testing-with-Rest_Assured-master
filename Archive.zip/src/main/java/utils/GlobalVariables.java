package utils;

public class GlobalVariables {
    public static String token;
    public static int bookingId;
}
